#!/bin/bash

numbers=({1..10})
rm report2.log
while :; do
    array+=("${numbers[@]}")
    ((counter++))
    if ((counter == 10000)); then
        echo "${#array[@]}" >> report2.log
        counter=0
    fi
done
