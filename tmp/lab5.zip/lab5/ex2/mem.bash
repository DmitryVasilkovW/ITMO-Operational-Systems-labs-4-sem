#!/bin/bash

numbers=({1..10})
rm report.log
while :; do
    array+=("${numbers[@]}")
    ((counter++))
    if ((counter == 10000)); then
        echo "${#array[@]}" >> report.log
        counter=0
    fi
done
