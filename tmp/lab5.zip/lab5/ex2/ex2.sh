#!/bin/bash

./handler.sh&pid0=$!
./handler2.sh&pid1=$!

