import matplotlib.pyplot as plt
import pandas as pd

data = pd.read_csv('data2', sep=' ', skiprows=1, header=None)
data.columns = ['TIME', 'MEM', 'VIRT', 'RES', 'SHR', 'CPU', 'FREE', 'SWAP']

data['TIME'] = pd.to_datetime(data['TIME'])

data['MEM'] = data['MEM'].str.replace(',', '.').astype(float)
data['SWAP'] = data['SWAP'].str.replace(',', '.').astype(float)

fig, axs = plt.subplots(4, figsize=(10, 15))

axs[0].plot(data['TIME'], data['SWAP'], label='SWAP', color='orange')
axs[0].set_xlabel('Time')
axs[0].set_ylabel('Free Memory')
axs[0].set_title('Free Swap Over Time')

axs[1].plot(data['TIME'], data['MEM'], label='MEM')
axs[1].set_xlabel('Time')
axs[1].set_ylabel('Memory Usage')
axs[1].set_title('Memory Usage Over Time')

axs[2].plot(data['TIME'], data['CPU'], label='CPU', color='r')
axs[2].set_xlabel('Time')
axs[2].set_ylabel('CPU Usage (%)')
axs[2].set_title('CPU Usage Over Time')
axs[2].invert_yaxis()

axs[3].plot(data['TIME'], data['VIRT'], label='VIRT', color='g')
axs[3].plot(data['TIME'], data['RES'], label='RES', color='b')
axs[3].set_xlabel('Time')
axs[3].set_ylabel('Memory Usage')
axs[3].legend()
axs[3].set_title('Virtual and Resident Memory Usage Over Time')

plt.tight_layout()
plt.show()
