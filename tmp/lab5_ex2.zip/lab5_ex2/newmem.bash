#!/bin/bash

array=()
numbers=({1..10})

N=${1:-4350000}

while :; do
    array+=("${numbers[@]}")
    ((counter++))
    if ((counter == 10000)); then
        counter=0
        if (( ${#array[@]} > N )); then
            echo "$N"
            exit 0
        fi
    fi
done
